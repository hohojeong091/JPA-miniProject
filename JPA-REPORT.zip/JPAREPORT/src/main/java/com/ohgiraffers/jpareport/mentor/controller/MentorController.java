package com.ohgiraffers.jpareport.mentor.controller;

import com.ohgiraffers.jpareport.common.Pagenation;
import com.ohgiraffers.jpareport.common.PagingButton;
import com.ohgiraffers.jpareport.mentor.dto.MenteeDTO;
import com.ohgiraffers.jpareport.mentor.dto.MentorDTO;
import com.ohgiraffers.jpareport.mentor.service.MentorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@Controller
@RequestMapping("/menu")
@RequiredArgsConstructor
public class MentorController {
    private MentorService mentorService;

//    private final ModelMapper modelMapper;

    @GetMapping("/{mentorId}")
    public String findMentorById (@PathVariable int mentorId, Model model) {
        MentorDTO resultMentor = mentorService.findMentorByMentorId(mentorId);
        model.addAllAttributes("mentor", resultMentor);
        return "mentor/detail";
    }

    @GetMapping("/list")
    public String findMentorList(Model model, @PageableDefault Pageable pageable) {
        PagingButton paging = Pagenation.getPagingButtonInfo(mentorList);
        model.addAllAttributes("mentorList", mentorList);
        model.addAllAttributes("paging", paging);
        return "mentor/list";

    }

    @GetMapping("/querymethod")
    public void querymethodPage(){

    }

    @GetMapping("search")
    public String findByMenteeId(@RequestParam Integer menteeId, Model model) {
        List<MenteeDTO> menteeList = mentorService.findByMenteeId(menteeId);
        model.addAllAttributes("menteeList", menteeList);
        return "mentee/searchMentee";
    }

    @GetMapping("/regist")
    public void registPage() {


    }

//    @GetMapping("/mentor/list")

    @PostMapping("/regist")
    public String registNewMentor(@ModelAttribute MentorDTO mentorDTO) {
        mentorService.registMentor(mentorDTO);
        return "redirect:/mentor/list";
    }

    @GetMapping("/modify")
    public void modifyPage(){}

    @PostMapping("/modilfy")
    public String modifyMentor(@ModelAttribute MentorDTO mentorDTO){
        mentorService.modifyMentor(mentorDTO);
        return "redirect:/mentor/list" + mentorDTO.getMentorId();
    }

    @GetMapping("/delete")
    public void deletePage(){}

    @PostMapping("/delete")
    public String deleteMentor(@RequestParam Integer mentorCode) {
        mentorService.deleteMentor(mentorCode);
        return"redirect:/mentor/list";
    }

}
