package com.ohgiraffers.jpareport.main.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MainController {

    @GetMapping("/main")
    public String main() {
        return "main/main";
    }

}
