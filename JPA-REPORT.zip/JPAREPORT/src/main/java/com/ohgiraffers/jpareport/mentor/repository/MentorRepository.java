package com.ohgiraffers.jpareport.mentor.repository;

import com.ohgiraffers.jpareport.mentor.entity.Mentor;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface MentorRepository extends JpaRepository<Mentor, Integer> {
    Object findByIdGreaterThan(int mentorId, Sort sort);

    void deleteById(Integer mentorId);

    Object findById(int mentorCode);
}
