package com.ohgiraffers.jpareport.mentor.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;

@Entity
@Table(name="tbl_mentor")
@Getter
public class Mentee {
    @Id
    private int menteeId;
    private String menteeName;
    private String menteePhone;
    private String menteeCapa;
    private String menteeAddress;
    private String menteeMatching;

}
