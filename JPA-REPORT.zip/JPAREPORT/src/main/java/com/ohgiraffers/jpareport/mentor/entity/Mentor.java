package com.ohgiraffers.jpareport.mentor.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name="tbl_mentor")
@Getter
@NoArgsConstructor(access= AccessLevel.PROTECTED)
public class Mentor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int mentorId;
    private String mentorName;
    private int mentorAge;
    private String mentorCapa;
    private String mentorAddress;
    private String mentorMatching;


    public void modifyMentor(int mentorId) {
        this.mentorId=mentorId;
    }
}
