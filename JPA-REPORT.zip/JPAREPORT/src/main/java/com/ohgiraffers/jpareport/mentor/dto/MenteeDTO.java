package com.ohgiraffers.jpareport.mentor.dto;

public class MenteeDTO {
    private int menteeId;
    private String menteeName;
    private String menteePhone;
    private String menteeCapa;
    private String menteeAddress;
    private String mennteeMatching;

    public MenteeDTO() {
    }

    public MenteeDTO(int menteeId, String menteeName, String menteePhone, String menteeCapa, String menteeAddress, String mennteeMatching) {
        this.menteeId = menteeId;
        this.menteeName = menteeName;
        this.menteePhone = menteePhone;
        this.menteeCapa = menteeCapa;
        this.menteeAddress = menteeAddress;
        this.mennteeMatching = mennteeMatching;
    }

    public int getMenteeId() {
        return menteeId;
    }

    public void setMenteeId(int menteeId) {
        this.menteeId = menteeId;
    }

    public String getMenteeName() {
        return menteeName;
    }

    public void setMenteeName(String menteeName) {
        this.menteeName = menteeName;
    }

    public String getMenteePhone() {
        return menteePhone;
    }

    public void setMenteePhone(String menteePhone) {
        this.menteePhone = menteePhone;
    }

    public String getMenteeCapa() {
        return menteeCapa;
    }

    public void setMenteeCapa(String menteeCapa) {
        this.menteeCapa = menteeCapa;
    }

    public String getMenteeAddress() {
        return menteeAddress;
    }

    public void setMenteeAddress(String menteeAddress) {
        this.menteeAddress = menteeAddress;
    }

    public String getMennteeMatching() {
        return mennteeMatching;
    }

    public void setMennteeMatching(String mennteeMatching) {
        this.mennteeMatching = mennteeMatching;
    }

    @Override
    public String toString() {
        return "MenteeDTO{" +
                "menteeId=" + menteeId +
                ", menteeName='" + menteeName + '\'' +
                ", menteePhone='" + menteePhone + '\'' +
                ", menteeCapa='" + menteeCapa + '\'' +
                ", menteeAddress='" + menteeAddress + '\'' +
                ", mennteeMatching='" + mennteeMatching + '\'' +
                '}';
    }
}
