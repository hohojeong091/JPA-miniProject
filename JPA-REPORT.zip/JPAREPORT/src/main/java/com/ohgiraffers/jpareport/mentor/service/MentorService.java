package com.ohgiraffers.jpareport.mentor.service;

import com.ohgiraffers.jpareport.mentor.dto.MenteeDTO;
import com.ohgiraffers.jpareport.mentor.dto.MentorDTO;
import com.ohgiraffers.jpareport.mentor.entity.Mentor;
import com.ohgiraffers.jpareport.mentor.repository.MenteeRepository;
import com.ohgiraffers.jpareport.mentor.repository.MentorRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MentorService {

    private MenteeRepository menteeRepository;

    private MentorRepository mentorRepository;
    private ModelMapper modelMapper;

       public MentorDTO findMentorByMentorId(int mentorCode) {
           MentorDTO foundMentor = mentorRepository.findById(mentorCode).orElseThrow(IllegalArgumentException::new);
        return modelMapper.map(foundMentor, MentorDTO.class);
    }

    public List<MenteeDTO> findByMenteeId(Integer menteeId) {
        List<MenteeDTO> menteeList = menteeRepository.findByMenteeId(
                menteeId,
                Sort.by("mentorId").descending());
        return menteeList.stream().map(mentee->modelMapper.map(mentee, MenteeDTO.class))
                .toList();
    }

    public void registMentor(MentorDTO mentorDTO) {
        mentorRepository.save(modelMapper.map(MentorDTO, Mentor.class));
    }

    @Transactional
    public void deleteMentor(Integer mentorId) {
        mentorRepository.deleteById(mentorId);
    }

    @Transactional
    public void modifyMentor(MentorDTO mentorDTO) {
        Mentor foundMentor = mentorRepository.findById(mentorDTO.getMentorId()).orElseThrow(IllegalArgumentException::new);
        foundMentor.modifyMentor(mentorDTO.getMentorId());
    }
}
