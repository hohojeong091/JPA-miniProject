package com.ohgiraffers.jpareport.mentor.dto;

public class MentorDTO {
    private int mentorId;
    private String mentorname;
    private int mentorAge;
    private String mentorCapa;
    private String mentorAddress;
    private String mentorMatching;

    public MentorDTO() {
    }

    public MentorDTO(int mentorId, String mentorname, int mentorAge, String mentorCapa, String mentorAddress, String mentorMatching) {
        this.mentorId = mentorId;
        this.mentorname = mentorname;
        this.mentorAge = mentorAge;
        this.mentorCapa = mentorCapa;
        this.mentorAddress = mentorAddress;
        this.mentorMatching = mentorMatching;
    }

    public int getMentorId() {
        return mentorId;
    }

    public void setMentorId(int mentorId) {
        this.mentorId = mentorId;
    }

    public String getMentorname() {
        return mentorname;
    }

    public void setMentorname(String mentorname) {
        this.mentorname = mentorname;
    }

    public int getMentorAge() {
        return mentorAge;
    }

    public void setMentorAge(int mentorAge) {
        this.mentorAge = mentorAge;
    }

    public String getMentorCapa() {
        return mentorCapa;
    }

    public void setMentorCapa(String mentorCapa) {
        this.mentorCapa = mentorCapa;
    }

    public String getMentorAddress() {
        return mentorAddress;
    }

    public void setMentorAddress(String mentorAddress) {
        this.mentorAddress = mentorAddress;
    }

    public String getMentorMatching() {
        return mentorMatching;
    }

    public void setMentorMatching(String mentorMatching) {
        this.mentorMatching = mentorMatching;
    }

    @Override
    public String toString() {
        return "MentorDTO{" +
                "mentorId=" + mentorId +
                ", mentorname='" + mentorname + '\'' +
                ", mentorAge=" + mentorAge +
                ", mentorCapa='" + mentorCapa + '\'' +
                ", mentorAddress='" + mentorAddress + '\'' +
                ", mentorMatching='" + mentorMatching + '\'' +
                '}';
    }
}
