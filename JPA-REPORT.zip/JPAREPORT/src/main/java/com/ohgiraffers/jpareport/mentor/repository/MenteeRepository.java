package com.ohgiraffers.jpareport.mentor.repository;

import com.ohgiraffers.jpareport.mentor.dto.MenteeDTO;
import com.ohgiraffers.jpareport.mentor.entity.Mentee;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface MenteeRepository extends JpaRepository<Mentee, Integer> {
    @Query(
            value="SELECT mentee_id, mentee_name, mentee_phone, mentee_capa, mentee_address, mentee_matching " +
                    "FROM tbl_mentor" +
                    " ORDER BY mentee_id",
            nativeQuery = true)
    List<MenteeDTO> findByMenteeId(Integer menteeId, Sort mentorId);
}
