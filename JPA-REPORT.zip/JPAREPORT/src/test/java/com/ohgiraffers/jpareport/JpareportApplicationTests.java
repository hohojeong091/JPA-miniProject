package com.ohgiraffers.jpareport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpareportApplicationTests {

    @Test
    void contextLoads() {
    }

}
